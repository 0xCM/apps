﻿//-----------------------------------------------------------------------------
// Copyright   :  (c) Chris Moore, 2021
// License     :  MIT
// Generated   : 2021-11-14 3:49:57 -06:00
//-----------------------------------------------------------------------------
namespace Z0.ByteCode
{
    using System;
    using System.Runtime.CompilerServices;


    public static class lib_ascicodes
    {
        public static ReadOnlySpan<byte> whitespaceヽᐤᐤ  =>  new byte[29]{0x0f,0x1f,0x44,0x00,0x00,0x48,0xb8,0xd0,0x47,0x66,0x4e,0x59,0x02,0x00,0x00,0x48,0x89,0x01,0xc7,0x41,0x08,0x06,0x00,0x00,0x00,0x48,0x8b,0xc1,0xc3};

    }
}
