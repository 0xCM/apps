﻿//-----------------------------------------------------------------------------
// Copyright   :  (c) Chris Moore, 2021
// License     :  MIT
// Generated   : 2021-11-14 3:49:55 -06:00
//-----------------------------------------------------------------------------
namespace Z0.ByteCode
{
    using System;
    using System.Runtime.CompilerServices;


    public static class calc_calcchecks
    {
        public static ReadOnlySpan<byte> checkerヽᐤIWfRuntimeᐤ  =>  new byte[31]{0x0f,0x1f,0x44,0x00,0x00,0x48,0x8b,0xd1,0x48,0xb9,0x00,0x40,0x64,0x78,0xfd,0x7f,0x00,0x00,0x48,0xb8,0xb0,0x3a,0xc1,0x79,0xfd,0x7f,0x00,0x00,0x48,0xff,0xe0};

    }
}
