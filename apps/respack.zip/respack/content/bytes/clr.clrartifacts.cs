﻿//-----------------------------------------------------------------------------
// Copyright   :  (c) Chris Moore, 2021
// License     :  MIT
// Generated   : 2021-11-14 3:49:55 -06:00
//-----------------------------------------------------------------------------
namespace Z0.ByteCode
{
    using System;
    using System.Runtime.CompilerServices;


    public static class clr_clrartifacts
    {
        public static ReadOnlySpan<byte> referenceヽᐤCliTokenㆍClrArtifactKindᕀ32uㆍNameᐤ  =>  new byte[31]{0x56,0x0f,0x1f,0x40,0x00,0x48,0x8b,0xf1,0x44,0x89,0x06,0x89,0x56,0x08,0x48,0x8d,0x4e,0x10,0x49,0x8b,0xd1,0xe8,0x16,0x30,0x7e,0x5b,0x48,0x8b,0xc6,0x5e,0xc3};

    }
}
