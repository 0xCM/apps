﻿//-----------------------------------------------------------------------------
// Copyright   :  (c) Chris Moore, 2021
// License     :  MIT
// Generated   : 2021-11-14 3:49:56 -06:00
//-----------------------------------------------------------------------------
namespace Z0.ByteCode
{
    using System;
    using System.Runtime.CompilerServices;


    public static class extract_xsvc
    {
        public static ReadOnlySpan<byte> ApiResolverヽᐤIWfRuntimeᐤ  =>  new byte[31]{0x0f,0x1f,0x44,0x00,0x00,0x48,0x8b,0xd1,0x48,0xb9,0x20,0x0f,0xf9,0x80,0xfe,0x7f,0x00,0x00,0x48,0xb8,0xc0,0x60,0x87,0x82,0xfe,0x7f,0x00,0x00,0x48,0xff,0xe0};

    }
}
