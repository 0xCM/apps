﻿//-----------------------------------------------------------------------------
// Copyright   :  (c) Chris Moore, 2021
// License     :  MIT
// Generated   : 2021-11-14 3:49:56 -06:00
//-----------------------------------------------------------------------------
namespace Z0.ByteCode
{
    using System;
    using System.Runtime.CompilerServices;


    public static class lib_calcchecks
    {
        public static ReadOnlySpan<byte> checkerヽᐤIWfRuntimeᐤ  =>  new byte[31]{0x0f,0x1f,0x44,0x00,0x00,0x48,0x8b,0xd1,0x48,0xb9,0x18,0x0f,0x1f,0x81,0xfe,0x7f,0x00,0x00,0x48,0xb8,0xc0,0x60,0x87,0x82,0xfe,0x7f,0x00,0x00,0x48,0xff,0xe0};

    }
}
